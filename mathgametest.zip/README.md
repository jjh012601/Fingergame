# Math-games
A simple math game written in python

video demo: 
https://youtu.be/R8UUBWTG0OQ
